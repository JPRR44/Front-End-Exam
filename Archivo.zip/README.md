La manera de correr este archivo es descargando toda la carpeta y dentro de la carpeta correr el comando 'npm install'

Una vez installado simplemente corra el comando 'npm start' para ver el resultado en el navegarod

Cuando me hicieron la llamada para informarme de la entrevista me informaron que tendría que contestar un examen previo a la entrevista de el viernes, sin embargo no llegamos a un acuerdo mutuo en la fecha, tomo en cuenta que yo tampoco pregunté así que fue en parte mi error.

El examen llegó por correo al rededor de las 7 de la tarde, sin embargo lo que ocurre es que tengo un familiar que esta un poco delicado de salud y tuve que ir a que lo curaran de 7-9 de la noche aproximadamente. Desafortunadamente con ese espacio de tiempo no logré hacer la total funcionalidad, lo que logré hacer fue lo siguiente:

Hice la parte visual de la app pensando en implementar un registro de usuarios y un login para comprobar los registros, el login funciona como debe de ser, si uno da click en 'login' e ingresa un correo que sí existe en la API, este pasa a mostrarte todo los usuarios de la API, en cambio si no existe manda un mensaje de error. 

Sé que es lo que me faltó, debo hacer otros dos fecth, uno para hacer el Delete de los usuarios y otro para el Update simplelemte que por lo que sucedió no logré terminar, no es así como me hubiera gustado entregarlo. Quisiera poner comentarios explicando el funcionamiento y los commits correctos en el git pero por lo ocurridi no lo pude hacer una disculpa. 