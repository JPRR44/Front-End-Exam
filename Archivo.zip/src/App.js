import React, {useState} from 'react';
import './App.css';
import Home from './containers/Home/Home';
import LoginCon from './containers/LoginForm/LoginCon';
import LoginScreen from './containers/LoginScreen/LoginScreen';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';

function App() {
  const [logged, setlogged] = useState();

  return (
   <Router>
      <Switch>
          <Route exact path="/" render={() => <Home setlogged ={setlogged} logged ={logged} />} />
          <Route path="/login" render={() => <LoginCon setlogged ={setlogged} logged ={logged}/>} />
          <Route path="/loginText" render={() => <LoginScreen />} />
      </Switch>
   </Router>
  );
}

export default App;
