import React, { Component } from 'react';
import './LoginScreen.css'
import LoginText from '../../components/logintext/logintext';

export default class LoginScreen extends Component {
    render() {
        return (
            <div id="LoginScreen">
                    <LoginText/>
            </div>
        )
    }
}
 