import React from 'react';
import './Home.css'
import RegisterForm from '../../components/register/register';
import { Container } from 'reactstrap';
import Navbar from '../../components/navbar/navbar';
import HomeMessage from '../../components/hometext/hometext';
import UserDashboard from '../userDashboard/userDashboard'


 const Home = ({setlogged, logged}) => {

        return (

            <div id="home" style={{ backgroundSize: 'cover' }}>
                <Navbar />
                {logged ? 
                <UserDashboard/>
                :
                <Container style={{display: "flex", height: '97%', maxWidth: '100%', margin: "0", justifyContent: "space-around", alignItems: "center"}}>
                            <HomeMessage id='colRegisterMessage' />
                            <RegisterForm />
                </Container>
                
                }
            </div>
        )
}

export default Home;