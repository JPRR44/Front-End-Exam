import React , {useEffect, useState} from 'react'
import './userDashboard.css'
 
 const UserDashboard = () => {
    const [Users, setUsers] = useState();

    useEffect(() => {
       fetch("https://reqres.in/api/users")
       .then(res => res.json())
       .then(res => {setUsers(res.data)})
        .catch(err => console.log(err))
       }, [])
 
    return (
    <div id = 'userDashboard'>
        <h1 id = 'users'>Users:</h1>

        {
            Users ? 
            Users.map(user => <li id='userCard' key = {user.id}>{user.email} </li>)
        :
            <h1>Users not found</h1>        
        }
        
    </div>
 )
}

export default UserDashboard