import React from 'react';
import './LoginCon.css'
import { Container } from 'reactstrap';
import Login from '../../components/Login/Login';

const Home = ({setlogged}) => {
        return (
            <div id="Login">
                <Container style={{ display: "flex", height: '100%%', maxWidth: '100%', margin: "0", justifyContent: "space-around", alignItems: "center" }}>
                    <Login id='Login' setLogged = {setlogged} />
                </Container>
            </div>
        )
    
}

export default Home;