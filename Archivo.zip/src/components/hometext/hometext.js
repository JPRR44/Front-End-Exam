import React from 'react';
import './hometext.css'
const HomeText = () => {
    return (
        <div style={{height: '40%', width: '35%'}}>
            <div id="homeMessage">
                <h1>Examen de front-end</h1>
                <h2>¿Listo para empezar?</h2>
            </div>

        </div>

    )
}

export default HomeText;