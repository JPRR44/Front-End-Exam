import React , {useState} from 'react';
import './Login.css';
import { Button, Form, FormGroup, Label, Input, Container } from 'reactstrap';
import { withRouter } from 'react-router-dom';

const Login = ({setLogged, history}) => {
    const [email, setemail] = useState("");
    const [psw, setpsw] = useState("");

    const recordEmailChange = (e) => {
        if (e.target.value !== email){
            setemail(e.target.value)
        }
    }
    const recordPswChange = (e) => {
        if (e.target.value !== psw){
            setpsw(e.target.value)
        }
    }

    const formSubmit = () => {
        if(!email || !psw){
            alert("There are some missing fields")
            return;
        }
        const body = {
            email, password:psw
        }
        fetch("https://reqres.in/api/register", {
            headers:{
                    'Content-Type': 'application/json'
            },
            method:'POST',
            body: JSON.stringify(body)
        }).then(res => res.json())
        .then(data => {
            setLogged(data)
            history.push("/")
            console.log(data)})
        .catch(err => console.log(err));
    }

    return (
        <div id="login" style={{width: '50%', height: '700px'}}>
            <Container id='containerLogin' style={{marginTop: '40px'}}>
                <Form>
                    <FormGroup>
                        <Label for="usernameLogin">Email</Label>
                        <Input type="text" value= {email} onChange={recordEmailChange} name="email" id="usernameLogin" placeholder="Enter your username or Email" />
                    </FormGroup>
                    <FormGroup>
                        <Label for="passwordLogin">Password</Label>
                        <Input type="password" value = {psw} name="psw" onChange={recordPswChange} id="passwordLogin" placeholder="Enter your password" />
                    </FormGroup>
                    <Button color="primary" onClick = {formSubmit} id="LoginButton">Submit</Button>
                </Form>
            </Container>
        </div>
    )
}

export default withRouter(Login);