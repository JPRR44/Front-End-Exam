import React from 'react';
import {Nav, Button} from 'react-bootstrap';
import './navbar.css'
import { Link } from 'react-router-dom';

const Navbar = () => {
    return(
       <div id = 'navbar'>
            <Nav defaultActiveKey="/home" as="ul">
                <Nav.Item as="li">
                    <Nav.Link href="/home" style={{color:'white'}}>WELCOME</Nav.Link>
                </Nav.Item>
                <Nav.Item as="li" style = {{marginLeft: "75em"}}>
                    <Link to = "/Login"><Button id = 'button'>Login</Button></Link>
                </Nav.Item>
            </Nav>
       </div>
    )
}

export default Navbar;