import React from 'react';
import {Button} from 'react-bootstrap';
import './logintext.css'
import { Link } from 'react-router-dom';

const LoginText = () => {
    return (
        <div style={{height: '40%', width: '35%'}}>
            <div id="homeMessage">
                <p> Hola XXXXX ¿Quieres borrar tu cuenta?</p>
                <Link to = "/"><Button id = 'buttonErase'>Borrar Cuenta</Button></Link>
            </div>

        </div>

    )
}

export default LoginText;